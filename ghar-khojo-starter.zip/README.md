# Ghar Khojo — Bhopal student accommodation MVP

A responsive React + Vite website starter with Capacitor Android packaging support.

## Included
- Dark, futuristic depth-inspired interface (no interactive 3D apartment models)
- Student enquiry form
- Search and filters for sample PG/hostel/room/flat listings
- Bhopal locality explorer
- One-year support messaging
- Local prototype admin panel for adding sample listings
- Capacitor configuration for generating an Android project

## Important before public launch
This is a frontend MVP scaffold, not a production booking or lead-management system.
- The sample property cards and prices are demo content. Replace them with real, permission-cleared and availability-confirmed listings.
- Enquiries currently save to the visitor's browser local storage only. They do not reach your team. Do not collect real student data until a secure backend and privacy notice are configured.
- Admin preview is not authenticated or secure. Do not expose it as a production admin panel.
- Add a real support phone/email, terms for the one-year support promise, privacy policy, property verification process and service-area details.
- Remote demo images use Unsplash URLs. Replace with photos uploaded with owner permission.
- Add backend validation, rate limiting, spam protection, secure admin authentication, database backups and role-based access before launch.

## Run the website
Install Node.js 20+ and npm, then:

```bash
npm install
npm run dev
```

Open the local URL printed by Vite (usually http://localhost:5173).

## Build the website
```bash
npm run build
```
The production website is generated in `dist/`.

## Create Android APK
You need Android Studio, Android SDK, and a compatible Java JDK installed.

```bash
npm install
npm run android:add
npm run android:sync
npm run android:open
```

In Android Studio:
1. Wait for Gradle sync.
2. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
3. For a distributable release, use **Build > Generate Signed Bundle / APK > APK** and create/store your signing key securely.
4. Test on multiple Android devices before distributing.

The generated Android project is in `android/`. The debug APK is typically at:
`android/app/build/outputs/apk/debug/app-debug.apk`

## Configure a production backend
Recommended MVP backend: Supabase (Postgres + Storage + Auth).
Create tables for:
- `properties`: title, type, locality, monthly_rent, deposit, sharing, gender_preference, facilities, photos, availability_status, verification_status
- `enquiries`: student_name, phone, email, college, preferred_locality, property_type, budget, move_in_date, notes, consent, status, created_at
- `support_tickets`: enquiry_id/student_id, category, description, status, created_at, updated_at

Enable Row Level Security. Public users should only be able to create enquiries and read published/approved properties. Only authenticated admin roles should be able to manage listings and see student contact details. Never put a Supabase service-role key in frontend code.

## Suggested brand details
- Brand: Ghar Khojo
- Tagline: Your home. Your city. Our support.
- Initial service city: Bhopal, Madhya Pradesh
- App ID: `in.gharkhojo.app`
